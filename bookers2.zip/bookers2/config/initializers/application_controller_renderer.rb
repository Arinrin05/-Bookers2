# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'ea24b643315a47f77e250735e713d4eb9a19d8ad4727f83c037f6ca0959f2f0558d73675633c68c3583c2b268b09f08efe84af89cbe99c8cce20da00308466a0'